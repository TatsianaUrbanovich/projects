package sanscrit;

public class Check {


	String w1;
	String w2;

	public String w1_end;
	public String w2_beg;
	public int len;
	String newSandhi="000";
	public String MessageM ="NULL";	
	
 public Check(String s1, String s2) {
	    len = s1.length();
	    if((s1.charAt(len-1)=='i'| s1.charAt(len-1)=='u')&s1.charAt(len-2)=='a'){
	    		w1_end = String.valueOf(s1.charAt(len-2))+String.valueOf(s1.charAt(len-1));
	    	} else
		w1_end = String.valueOf(s1.charAt(len-1));
	   if((s2.charAt(0)=='a')&(s2.charAt(1)=='i')| (s2.charAt(1)=='u')) {
			w2_beg = String.valueOf(s2.charAt(0))+String.valueOf(s2.charAt(1));
	   } else
		w2_beg = String.valueOf(s2.charAt(0));
	 
 }

 public String addition(String D, String F) {
	 if (D.equals("a")) {
		 switch (F) {
		 	case "i": newSandhi = "e"; break;
			case "u": newSandhi = "o"; break;
			case "r": newSandhi = "ar"; break;
			case "l": newSandhi = "al"; break;
		 	case "e": newSandhi = "ai"; break;
			case "ai": newSandhi = "ai"; break;
			case "o": newSandhi = "au"; break;
			case "au": newSandhi = "au"; break;
		 }
		 if(
		    F.contentEquals("i") | F.contentEquals("u")
		  | F.contentEquals("r") | F.contentEquals("l")
		  | F.contentEquals("e") | F.contentEquals("ai")	
		  | F.contentEquals("o") | F.contentEquals("au")	
			) MessageM = "Sandhi is: "+newSandhi+". Type is: Ekadesha"; else MessageM = "Wrong input";
		 return newSandhi;
	  } else {
		  switch (D) {
			case "i": newSandhi = "ya"; break;
			case "u": newSandhi = "v"; break;
			case "r": newSandhi = "r"; break;
			case "l": newSandhi = "l"; break;
			case "e": newSandhi = "aya"; break;
			case "ai": newSandhi = "aaya"; break;
			case "o": newSandhi = "av"; break;
			case "au": newSandhi = "aav"; break;
		  }
		  if((F.contentEquals("i") | F.contentEquals("u")
			| F.contentEquals("r") | F.contentEquals("l")
			| F.contentEquals("e") | F.contentEquals("o")
			| F.contentEquals("au") | F.contentEquals("ai")| F.contentEquals("a")
			) &
			 (D.contentEquals("i") | D.contentEquals("u")
			| D.contentEquals("r") | D.contentEquals("l")
			| D.contentEquals("e") | D.contentEquals("o")
			| D.contentEquals("au") | D.contentEquals("ai"))
		     ) MessageM = "Sandhi is: "+newSandhi+". Type is: Adesha"; else MessageM = "Wrong input";
		}
	 if (newSandhi=="0") MessageM = "Wrong input";
	 return newSandhi;

 }
 
}
