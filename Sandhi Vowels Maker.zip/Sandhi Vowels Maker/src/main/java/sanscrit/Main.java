package sanscrit;

public class Main {

	public static void main(String[] args) {

		String S1="wwwau";
		String S2="aisss";
		
		//Taking end and begining of words.
		Check word12 = new Check(S1,S2);
		System.out.println("word1_end: "+ word12.w1_end + " word2_beg: " + word12.w2_beg +" Length: "+word12.len);
		
		word12.addition(String.valueOf(word12.w1_end), String.valueOf(word12.w2_beg));

	


	}




}
