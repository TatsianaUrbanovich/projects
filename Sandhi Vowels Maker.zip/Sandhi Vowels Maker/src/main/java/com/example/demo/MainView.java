package com.example.demo;

import com.vaadin.flow.component.Key;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinRequest;

import sanscrit.Check;

import java.awt.*;

import org.springframework.web.bind.annotation.RequestMapping;

@Route("test")
public class MainView extends VerticalLayout {

    public MainView() {
    	
 	  	
        VerticalLayout todosList = new VerticalLayout(); // (1)
        
        TextField taskField = new TextField(); // (2)

        
        TextField taskField2 = new TextField(); // (2)
       

        
        taskField.setLabel("word #1");
        taskField.setPlaceholder("firth word here");
       taskField2.setLabel("word #2");
      taskField2.setPlaceholder("second word here");
       
      
      Button addButton = new Button("Add"); // (3)
      addButton.addClickShortcut(Key.ENTER);
      
      addButton.addClickListener(click -> {
        	
        	String S1 = taskField.getValue();
        	String S2 = taskField2.getValue();
        	
            Check Words = new Check(S1,S2); 
            
          	String Final_mess1 = "End of firth word id: "+ Words.w1_end+". " + "Begining of second word is : " + Words.w2_beg+". ";
            String Sandhi =Words.addition(String.valueOf(Words.w1_end), String.valueOf(Words.w2_beg));
            String Final_mess2=Words.MessageM;
            add(new Span(Final_mess1));
            add(new Span(Final_mess2));


        });
        add( // (5)
            new H1("Sandhi volwers"),
            new HorizontalLayout(
            taskField,taskField2), new HorizontalLayout(addButton)
        );
    }
}